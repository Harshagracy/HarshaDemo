import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart, WebPartContext } from '@microsoft/sp-webpart-base';
import { IPropertyFieldGroupOrPerson } from "@pnp/spfx-property-controls/lib/PropertyFieldPeoplePicker";
export interface IPnPExamplesWebPartProps {
    description: string;
    context: WebPartContext;
    lists: string | string[];
    people: IPropertyFieldGroupOrPerson[];
}
export default class PnPExamplesWebPart extends BaseClientSideWebPart<IPnPExamplesWebPartProps> {
    protected onInit(): Promise<void>;
    render(): void;
    protected onDispose(): void;
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=PnPExamplesWebPart.d.ts.map