import * as React from 'react';
import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface IDisplayProductProps {
    context: WebPartContext;
}
export interface IDisplayProductStates {
    items: any[];
    isOpen: boolean;
    selectedItem: any;
}
export default class DisplayProduct extends React.Component<IDisplayProductProps, IDisplayProductStates> {
    constructor(props: IDisplayProductProps, state: IDisplayProductProps);
    componentWillMount(): void;
    getAllProducts(): void;
    onEditClick: (item: any) => void;
    render(): React.ReactElement<IDisplayProductProps>;
    onDismiss: () => void;
}
//# sourceMappingURL=DisplayProduct.d.ts.map