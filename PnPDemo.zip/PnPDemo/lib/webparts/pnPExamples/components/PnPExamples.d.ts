import * as React from 'react';
import { IPnPExamplesProps } from './IPnPExamplesProps';
export default class PnPExamples extends React.Component<IPnPExamplesProps, {}> {
    render(): React.ReactElement<IPnPExamplesProps>;
}
//# sourceMappingURL=PnPExamples.d.ts.map