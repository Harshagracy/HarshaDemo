import { SPRest } from '@pnp/sp';
import "@pnp/sp/webs";
import "@pnp/sp/items/list";
import "@pnp/sp/lists";
export declare const sp: SPRest;
//# sourceMappingURL=PnPPreset.d.ts.map