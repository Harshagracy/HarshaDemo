import * as React from 'react';
import { IPickerTerm } from "@pnp/spfx-controls-react/lib/TaxonomyPicker";
import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface IEditProductProps {
    Item: any;
    context: WebPartContext;
    updateParent: Function;
}
export interface IEditProductStates {
    title: string;
    quantity: number;
    term: IPickerTerm;
}
export default class EditProduct extends React.Component<IEditProductProps, IEditProductStates> {
    constructor(props: IEditProductProps, state: IEditProductStates);
    componentWillMount(): void;
    private getTerm;
    private saveItem;
    private deleteItem;
    private onTaxPickerChange;
    render(): React.ReactElement<IEditProductProps>;
}
//# sourceMappingURL=EditProduct.d.ts.map