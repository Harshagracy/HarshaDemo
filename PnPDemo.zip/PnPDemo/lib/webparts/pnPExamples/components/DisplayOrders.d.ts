import * as React from 'react';
import "@pnp/sp/webs";
import "@pnp/sp/items/list";
import "@pnp/sp/lists";
import "@pnp/sp/site-users/web";
export interface IDisplayOrdersProps {
}
export interface IDisplayOrdersStates {
    allOrders: any[];
    currentUserId: number;
}
export default class DisplayOrders extends React.Component<IDisplayOrdersProps, IDisplayOrdersStates> {
    constructor(props: IDisplayOrdersProps, state: IDisplayOrdersStates);
    componentWillMount(): void;
    getAllOrders: () => void;
    getUserId: () => void;
    private _getSelection;
    render(): React.ReactElement<IDisplayOrdersProps>;
    addItems: () => void;
}
//# sourceMappingURL=DisplayOrders.d.ts.map