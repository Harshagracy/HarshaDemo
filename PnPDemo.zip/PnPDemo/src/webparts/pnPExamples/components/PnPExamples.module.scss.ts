/* tslint:disable */
require("./PnPExamples.module.css");
const styles = {
  pnPExamples: 'pnPExamples_3280b959',
  container: 'container_3280b959',
  row: 'row_3280b959',
  column: 'column_3280b959',
  'ms-Grid': 'ms-Grid_3280b959',
  title: 'title_3280b959',
  subTitle: 'subTitle_3280b959',
  description: 'description_3280b959',
  button: 'button_3280b959',
  label: 'label_3280b959'
};

export default styles;
/* tslint:enable */